% test_PSWT_envelope_analysis is a Matlab(r) script that allows to test the attack time and noise ducking time 
% estimation by means of the Pitch Synchronous Wavelet Transform (PSWT)
%
% This software, including the function called "PSWT_envelope_analysis_lite.m" and functions therein is exclusively provided as a demonstrator of the methods and algorithms for the analysis of envelopes of instrument sounds 
% described in the paper "A Wavelet-Based Method for the Estimation of Clarity of Attack Parameters in Non-Percussive Instruments" 
% by G. Evangelista and A. Acquilino, submitted for publication to the
% DAFx25 Conference, Ancona, Italy, Sept. 2-5, 2025
%
% Any other use in non-profit or commercial applications without explicit consent by the authors is strictly forbidden
% Limited use in academic non-profit research is allowed provided that the source is duly mentioned, which includes citating the above mentioned
% publication and previous publications by each one of the authors.
%
% Copyright (c) 1994-2025 by G. Evangelista and A. Acquilino
%
% parameters to be set
sounddir=fullfile('.','Sounds'); % directory where the sound signals are stored 
audio_fn='Bb4_bad3.wav';
oversample=12;  % overall oversampling factor to enhance pitch detection
freqrange=[100,4000];  % frequency range to be used in pitch detection (large upper frequency may slow down computation, too smal may result in wrong pitch estimate)
WTScales=4;  % number of wavelet scales
load DAUBEC7.mat % wavelet FIR QMF filters
envfc=30; % Hz noise envelope filter cutoff frequency
envfiltorder=3; % noise envelope Butterworth low pass filter order (filtfilt is used for 0 phase)
play_fluctuations=true; % set to false to mute the audio output
% end of parameters to be set 

disp(['Reading file ',audio_fn,' in directory ',sounddir,' ...'])
[s_in,fs]=audioread(fullfile(sounddir,audio_fn));
disp('Analyzing envelopes with PSWT and, for comparison, with Timbre Toolbox...')

[t_off,t_nd,TT_toff,eff_toff,per,cp,e_h,e_f,e_in,s_h,s_f,s_din]=PSWT_envelope_analysis_lite(s_in,h,g,WTScales,fs,oversample,freqrange,envfc,envfiltorder);

scrsize=get(0, 'ScreenSize'); scrsize(2)=ceil(scrsize(4)/2); scrsize(4)=scrsize(2); 
han=figure('OuterPosition',scrsize);
tm=(0:length(s_din)-1)'/fs;
plot(tm,s_din,'LineWidth',1.5),hold on
plot(tm,e_in,'b','LineWidth',2);
tm=(0:length(e_h)-1)'/fs;
plot(tm,e_h,'r','LineWidth',2);
ax=axis;
plot(tm,e_f,'Color',[.8,.7,0],'LineWidth',3);
disp('<')
disp(sprintf('Detected center pitch: %0.1f Hz',cp));
% process TT_toff
TTtoffstr=[sprintf('%0.0f',TT_toff*1000),' ms'];
disp(['Timbre Toolbox (-3dB max of original sound envelope) t_off = ',TTtoffstr])
TTtoffstr=['$\max e_{in}-3dB\ t_{off} =\ $',TTtoffstr];
plot(TT_toff*[1 1],[-1,+1],'Color',[.6,.6,.8],'LineWidth',2);

% process t_off
toffstr=[sprintf('%0.0f',t_off*1000),' ms'];
disp(['PSWT (-3dB max of harmonic ensemble envelope) t_off = ',toffstr])
toffstr=['PSWT $t_{off} =\ $',toffstr];
d=(t_off==TT_toff)/1000; %shift lines by a small amount in case of coincident t_off and TTt_off
plot((t_off+d)*[1,1],[-1,+1],'k','LineWidth',1.5)

% process eff_toff
efftoffstr=[sprintf('%0.0f',eff_toff*1000),' ms'];
disp(['Timbre Toolbox Weakest Effort t_off = ',efftoffstr])
efftoffstr=['TimTbx effort $t_{off} =\ $',efftoffstr];
d=((eff_toff==TT_toff)+(eff_toff==t_off))/1000; %shift lines by a small amount in case of coincident critical times
plot((eff_toff+d)*[1,1],[-1,+1],'Color',[0,0.7,0],'LineWidth',2);

% process t_nd
tndstr=[sprintf('%0.0f',t_nd*1000),' ms'];
disp(['PSWT Noise Ducking Time t_nd = ',tndstr])
tndstr=['PSWT $t_{nd} =\ $',tndstr];
d=((t_nd==TT_toff)+(t_nd==t_off)+(t_nd==eff_toff))/1000; % shift lines by a small amount in case of coincident critical times
plot(t_nd*[1,1],[-1,+1],'k:','LineWidth',2);
disp('>')
disp('Displaying results...')
maxt=max([2*TT_toff,2*t_off,2*eff_toff,2*t_nd, ax(2)/5]); % adjust axis zoomed view to fit the max critical time
ax(2)=maxt; 
axis(ax);
xlabel('time (sec.)'), title(sprintf('Envelope Analysis of %s by means of PSWT',audio_fn),'Interpreter','none')
legend('Input signal','Input signal envelope $e_{in}$','Harmonic envelope', ...
    'Fluctuations envelope',TTtoffstr,toffstr,efftoffstr,tndstr,...
    'FontSize',14,'Interpreter','latex')
figure(han)
if play_fluctuations
    disp('Playing the fluctuation noise signal (type play(p) to play it again)...')
    p = audioplayer(s_f/max(abs(s_f)), fs);
    play(p);
end
