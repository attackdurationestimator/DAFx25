function [t_off,t_nd,TT_toff,effort_toff,per,cp,e_h,e_f,e_in,s_h,s_f,s_din]=PSWT_envelope_analysis_lite(s_in,h,g,WTScales,fs,oversample,freqrange,envfc,envfiltorder)
%
% PSWT_envelope_analysis_lite is a set of functions written in the Matlab(r) language, which allows to compute the attack time and noise ducking time 
% estimates by means of the Pitch Synchronous Wavelet Transform (PSWT)
%
% This software is exclusively provided as a demonstrator of the methods and algorithms for the analysis of envelopes of instrument sounds 
% described in the paper "A Wavelet-Based Method for the Estimation of Clarity of Attack Parameters in Non-Percussive Instruments" 
% by G. Evangelista and A. Acquilino, submitted for publication to the
% DAFx25 Conference, Ancona, Italy, Sept. 2-5, 2025
%
% Any other use in non-profit or commercial applications without explicit consent by the authors is strictly forbidden
% Limited use in academic non-profit research is allowed provided that the source is duly mentioned, which includes citating the above mentioned
% publication and previous publications by each one of the authors.
%
% INPUT VARIABLES
% s_in : input signal (a short, 150ms silence should be contained at the beginning of the signal to adaptively evaluate the background noise threshold)
% h,g : respectively, low pass and high pass FIR Quadrature Mirror Filters for use in the wavelet transform
% WTScales : Number of wavelet scales 
% fs : sampling rate of the input signal
% oversample : integer oversampling factor
% freqrange : frequency range [fmin, fmax] for pitch detection
% envfc : cutoff frequency in Hz for the noisy component envelope smoothing (default 30 Hz)
% envfiltorder : integer order of the Butterworth noisy component envelope filter (default 3)
%
% OUTPUT VARIABLES
% t_off : attack offset time (the software automatically aligns the onset of the signal to time t=0, so t_off is also the duration of the attack) 
% t_nd, : noise ducking time, i.e. the instant in whcih the noisy component subsides to the harmonic ensemble signal
% TT_toff : Timbre Toolbox (old version) estimate of the attack offset obtained by thresholding the input signal envelope
% effort_toff : Timbre Toolbox (new) estimate of the attack offset by means of the weakest effort method (G. Peeters et al.)
% per : chain of estimated oversampled local periods of the signal
% e_h : envelope of the harmonic ensemble signal
% e_f : envelope of the noisy fluctuation signal
% e_in : envelope of the input signal
% s_h : harmonic ensemble signal deriving from PSWT scaling projection
% s_f : noisy fluctuations signal deriving from PSWT wavelet set projection 
% s_din : de-padded signal where the leading and trailing silence has been cut

%
% Copyright (c) 1994-2025 by G. Evangelista and A. Acquilino
%
    FLfactor=1.1; % extension factor of the FrameLength as estimated from the periods' mode
    initialsegdur=150; % ms of the initial segment where backround noise is estimated
    if nargin<8
        envfiltorder=3;
        if nargin<7
            envfc=30; % Hz
        end
    end

    s_din=depad(s_in,0.1,fs,initialsegdur); % estimate noise threshold and remove leading and trailing silence

    [s_h,s_f,per]=PSWT_separation(s_din,h,g,WTScales,fs,oversample,freqrange); % compute PSWT noise/harmonic ensemble separation
    cp=oversample*fs./per;
    ii=find((cp<freqrange(2)*0.95)&(cp>freqrange(1)*1.05)); % try to eliminate outliers when the pitch hits the edges of the frequency range (or when no pitch is detected for which pitch detection outputs max frequency)
    cp=oversample*fs/mode(per(ii));  % estimate f0 from the mode of the periods
    
    if cp>freqrange(2)*0.9, warning('maximum pitch detected too often, please consider broadening the frequency range'); end
    ii=oversample*fs./per<freqrange(2)*5/6; % consider as outliers (failed pitch detection) pitches that are above 5/6 of the max frequency in freqrange
    FrameLength=round(FLfactor*mode(per(ii))/oversample); % choose a FrameLength of about 1 period of the signal (it may fail for multiple pitched signal, obtaing oscillating envelopes, in that case try increasing FLfactor)
    e_in=p_envelope(s_din,FrameLength); % estimate the envelope of the input signal

    TT_toff=(find(e_in>max(e_in)*10^(-3/20),1)-1)/fs; % estimate the attack offset time by direct thresholding the input signal envelope (old school method)
    ieffTToff=weakest_effort(e_in); % estimate the index of the attack offset time using the weekest effort method
    effort_toff=ieffTToff/fs; % convert the offset index to human time
    e_h=p_envelope(s_h,FrameLength); % estimate the envelope of the harmonic ensemble signal
    Ah=max(e_h);
    t_off=(find(e_h>Ah*10^(-3/20),1)-1)/fs; % estimate the attack offset time by thresholding the envelope of the harmonic ensemble
    e_f=p_envelope(s_f,FrameLength); % estimate the envelope of the noisy component (wavelet fluctuation ensemble)
    % filter fluctuations envelope
    Af=max(e_f);
    [b,a]=butter(envfiltorder,2*envfc/fs); % design the smoothing filter for the noisy component envelope
    e_f=filtfilt(b,a,e_f);
    e_f=Af*e_f/max(e_f); % recover the original max amplitude of the noise peak

    if Af>Ah*10^(-15/20) % conditional estimate of the noise ducking time index; if passed find the noise max and track when the envelope e_f decays till 3dB below e_h 
        [~,imef]=max(e_f);
        it_nd=find(e_h(imef+1:end)*10^(-3/20)>e_f(imef+1:end),1);
        if ~isempty(it_nd)
            it_nd=it_nd+imef;
        else % the harmonic envelope never takes over the noise
            it_nd=length(e_h)+1;
            warning('Something may have gone wrong: the harmonic ensemble never took over the noise. Perhaps the freqrange for pitch is too narrow or perhaps the sound is almost all pure noise.')
        end
    else % the noise level is low (do not look for the peak of e_f and simply declare noise ducking when e_f falls below 3dB below e_h)
       it_nd=find(e_h>=Af*10^(3/20),1,'first'); 
    end
    t_nd=(it_nd-1)/fs; % convert the noise ducking time index to human time
end

function env=p_envelope(signal,FrameLength)
%
% env=p_envelope(signal,FrameLength) computes the envelope of signal using
% the sliding window max method and linear interpolation, using FrameLength
% as the window length and half FrameLength as hop length

%
% Copyright (c) 1994-2025 by G. Evangelista
%
    Ls=length(signal);
    if rem(FrameLength,2)==1, FrameLength=FrameLength+1; end % adjust the FrameLength to an even number
    hop_size=FrameLength/2; % hop by half the frame length
    % prepend hop_size zeros so we start computing envelope within windows centered
    % on negative time but still overlapping with the signal 
    signal=[zeros(hop_size,1); signal];
    a=rem(length(signal),FrameLength);
    if a>0, signal=[signal;zeros(FrameLength-a,1)]; end % pad signal with zeros to reach a length that is an integer multiple of FrameLength
    L=length(signal);
    C=L/FrameLength;
    S=reshape(signal,FrameLength,C);  
    env(1:2:2*C,1)=max(S)';
    signal=[signal(hop_size+1:end);zeros(hop_size,1)]; % shift signal (instead of window) and append hop_size zeros for the window to partially cover the end of the signal
    L=length(signal);
    C=L/FrameLength;
    S=reshape(signal,FrameLength,C);  
    env(2:2:2*C,1)=max(S)';
    Le=length(env);
    env = interp1(hop_size*(0:Le-1)',env,(0:Ls-1)','linear')';
end

function [s_h,s_f,per]=PSWT_separation(s_in,h,g,WTScales,fs,oversample,freqrange)
%
% [s_h,s_f,per]=PSWT_separation(s_in,h,g,WTScales,fs,oversample,freqrange)
% computes the harmonic ensemble / noisy component separation using the PSWT
%
% INPUT VARIABLES
% s_in : input signal
% h,g : respectively, low pass and high pass FIR Quadrature Mirror Filters for use in the wavelet transform
% WTScales : Number of wavelet scales 
% fs : sampling rate of the input signal
% oversample : integer oversampling factor
% freqrange : frequency range [fmin, fmax] for pitch detection
%
% OUTPUT VARIABLES
% s_h : harmonic ensemble signal resulting from the separation
% s_f : noisy component signal resulting from the wavelet fluctuations ensemble 
% per : chain of oversampled detected signal periods

%
% Copyright (c) 1994-2025 by G. Evangelista
%
    s_in=resample(s_in,oversample,1); % overall upsample the input signal by the constant factor oversample
    [~,per]=pitchvar(s_in,oversample*fs,freqrange); % detect chain of oversampled period lengths per
    maxper=max(per); % compute the max period at which we will run the PSWT
    s_in=upsamplevar(s_in,per); % stretch each signal period to the max length period
    [s_f,s_h]=flucts(s_in,h,g,maxper,WTScales); % compute the PSWT separation (PSWT analysis and separate wavelets and scaling synthesis)
    s_f=downsamplevar(s_f,per); % re-shrink each segment of the noisy signal
    s_h=downsamplevar(s_h,per); % re-shrink each period of the harmonic ensemble
    s_f=resample(s_f,1,oversample); % overall dwonsample to original sampling rate the noisy signal 
    s_h=resample(s_h,1,oversample); % overall dwonsample to original sampling rate the harmonic ensemble signal 
end

function [s_f,s_h]=flucts(s_in,h,g,P,M)
%
% [s_f,s_h]=flucts(s_in,h,g,P,M) computes the multiplexed WT analysis and separate wavelet and scaling synthesis to separate the noisy component and the harmonic ensemble
%
% INPUT VARIABLES
% s_in : input signal
% h,g : respectively, low pass and high pass FIR Quadrature Mirror Filters for use in the wavelet transform
% P : number of de-multiplexing / multiplexing channels 
% M : Number of wavelet scales 

%
% Copyright (c) 1994-2025 by G. Evangelista
%
	[a,b,map]=fwtof(s_in,h,g,P,M); % compute multiplexed wavelet transform analysis
	s_f=ifwtof(zeros(size(a)),b,map,h,g,P); % compute the multiplexed wavelet transform synthesis masking the scaling coefficients
	s_h=ifwtof(a,zeros(size(b)),map,h,g,P); % compute the multiplexed wavelet transform synthesis masking the wavelet coefficients
end

function [a,b,map]=fwtof(aa,h,g,P,M)
%
%   FWTOF: [a,b,map]=fwtof(s_in,h,g,P,M) computes the (multiplexed) wavelet
%   transform of the signal s_in, using:
%   QMF filters h (lowpass) and g (highpass) as found in daubec??.mat  
%   an integer P denoting period in number of samples
%   an integer M denoting the max number of scales in wavelet analysis
% 
%   The matrices a and b, respectively, contain the scaling and wavelet coefficients organized 
%   columnwise for each of the P component wavelet transforms 
%   and row-wise with respect to scale  
%   The vector map decodes the starting and ending of each scale component.
%   For example:
%   b(map(n)+1:map(n+1),:)  contains the scale n wavelet coefficients for all of the P wavelet transforms 
%
%   For perfect reconstruction only the higher scale scaling coefficients are
%   needed, together with the ensemble of wavelet coefficients b
%
%   If s_in is a matrix the (multiplexed) wavelet transform is computed
%   columnwise and the coefficients a and b of the various signals are
%   intertwined, alternating the corresponding cooefficients for each signal .

%
%   Copyright (c) 1994-2025 by G. Evangelista.   
%
	a=[]; b=[];
	L=length(h)-1;
	h=h(:)/norm(h); g=g(:)/norm(g);
	map(1)=0;
	if size(aa,1)==1, aa=aa(:); end % make a column in case of single signal
	aa=demux(aa,P);
	[R K]=size(aa);
	aa=[zeros(1,K); aa]; % this is to get the odd samples in downsampling
	for k=1:M
			bb=upfirdn(aa,g,1,2); 
			b=[b;bb(2:end,:)];
			aa=upfirdn(aa,h,1,2);
			a=[a;aa(2:end,:)];
			[map(k+1),K]=size(a);
	end
end

function aa=ifwtof(a,b,map,h,g,P,cancel)
%
% IFWTOF: s_out=ifwtof(a,b,map,h,g,P,cancel) computes the inverse (multiplexed) wavelet
% transform using:
%   The matrices a and b, respectively, containing the scaling and wavelet coefficients organized 
%   columnwise for each of the P component wavelet transforms 
%   and row-wise with respect to scale (as found in fwtof.m)
%   The vector map decoding the starting and ending of each scale component (as found in fwtof.m).
%   QMF filters h (lowpass) and g (highpass) as found in daubec??.mat (and identical to those used in the analysis for orthogonal wavelets) 
%   An integer P denoting period in number of samples
%   An optional integer array cancel can be provided to set to zero some of
%   the analysis coefficients (scalewise), to obtain partial
%   reconstruction. The scaling component corresponds to the highest index
%   in cancel
% 
%   For example:
%   For an M scale wavelet analyisis, invoking
%   ss=ifwtof(a,b,map,h,g,P,[M+1]);
%   returns wavelet synthesis devoid of the scaling component

%
% Copyright (c) 1994-2025 by G. Evangelista.   
%   
	L=length(map)-1;
	N=length(h);
	h=h(N:-1:1)/norm(h);h=h(:);
	g=g(N:-1:1)/norm(g);g=g(:);
	N=N-1;
	if nargin>6 %there is a cancel vector argument
		[R,K]=size(b);
		for k=cancel
			b(map(k)+1:map(k+1),:)=zeros(map(k)+1:map(k+1),K);
		end
	end
	aa=a(map(L)+1:map(L+1),:);
	for k=L:-1:1
			bb=b(map(k)+1:map(k+1),:);
			[Lbb,K]=size(bb); [Laa,K]=size(aa);
			if Lbb>Laa, bb=bb(1:Laa,:); end
			bb=upfirdn(bb,g,2);
			bb=bb(1:end-N+1,:);
			if Laa>Lbb, aa=aa(1:Lbb,:); end
			aa=upfirdn(aa,h,2);
			aa=aa(1:end-N+1,:);
			aa=aa+bb; [R,K]=size(aa);
			aa=aa(N:R,:);
	end
	aa=mux(aa,P);
end

function s=demux(s,P)
%
%   DEMUX: s_out=demux(s_in,P) demultiplex data in array s_in by integer P
%   so that a matrix s_out is formed whose rows contain batches of P
%   subsequent samples of s_in

%
%   Copyright (c) 1994-2025 by G. Evangelista.   
%	

	[R,C]=size(s);
	K=ceil(R/P);
	s=[s; zeros(P*K-R,C)];
	s=reshape(s',C*P,K)';
end

function s=mux(s,P)
%
%   MUX: s_out=demux(s_in,P) multiplex data in matrix s_in by integer P
%   so that a signal s_out is formed by juxtaposing the columns of s_in

%
%   Copyright (c) 1994-2025 by G. Evangelista.   
%	   
	[R,C]=size(s);
	s=reshape(s',C/P,P*R)';
end

function s=depad(s,maxthr,fs,ms)
%
% ss=depad(s,maxthr,fs,ms) remove low amplitude segments from signal s using adaptive threshold. 
% A threshold is estimated from the first few ms of the signal, which are
% supposed to contain background noise only.
% ms (optional, default 150 ms), time in ms of the duration of the
% background noise segment (adaptively shortened if samples above maxthr
% are found)
% fs = sampling rate (default 48 KHz)
% maxthr (default 0.2) decides the max amplitude of signal samples for which the background segment is adaptively shortened
%
% Copyright (c) 1994-2025 by A. Acquilino and G. Evangelista
%
	if nargin<4,
		ms=150;
		if nargin<3,
			fs=48000; 
			if nargin<2,
				maxthr=.2;
			end
		end
    end	

	%find the adaptive threshold from initial silence
	Mamp=max(abs(s));
	max_amp_first=Mamp; 
	short=ms/1000; %initially specified ms but if sound starts earlier we need to shorten
	while max_amp_first>maxthr*Mamp
		% Extract the first milliseconds of the audio signal
		first_samples = round(short * fs); % Number of samples in the first (1000*short) milliseconds
		short_segment = s(1:min([first_samples, length(s)])); % Ensure segment is within bounds
		% Compute the max amplitude of the short segment 
		max_amp_first=max(abs(short_segment));
		short=short*0.9;
	end
	% Calculate adaptive threshold with margin
	thr = max_amp_first;
	idm=find(abs(s)>2*thr,1,'first');
	s=s(idm:end);
	idm=find(abs(s)>2*thr,1,'last');
	s=s(1:idm);
end

function [P,per]=pitchvar(s,fs,freqrange)
    if nargin<3, freqrange=[100,1500]; end
    winlen=max([ceil(fs/freqrange(1))+1,round(fs*0.052/2.4)]);
    ovlen=round(fs*0.042/2.4);
    L=length(s);
    ofs=1; k=1;
    while L>=(ofs+winlen-1)
        P(k)=pitch(s(ofs:ofs+winlen-1),fs,Range=freqrange,WindowLength=winlen,OverlapLength=ovlen);
        per(k)=round(fs/P(k));
        ofs=ofs+per(k);
        k=k+1;
    end
end

function sr=upsamplevar(s,per)
    maxper=max(per);
    sr=[];
    ofs=1;
    for k=1:length(per)
        sres=resample(s(ofs:ofs+per(k)-1,1),maxper,per(k));
        sres=sres(:);
        sr=[sr;sres];
        ofs=ofs+per(k);
    end
end

function sd=downsamplevar(s,per)
    maxper=max(per);
    sd=[];
    ofs=1;
    
    for k=1:length(per)
        sres=resample(s(ofs:ofs+maxper-1),per(k),maxper);
        sd=[sd;sres];
        ofs=ofs+maxper;
    end
end

function [attEndIdx,attStartIdx]=weakest_effort(env,multiplier,noiseThresh)
%
% [attEndIdx,attStartIdx]=weakest_effort(env,multiplier,noiseThresh)
% computes the attack boundaries using the weakest effort method where
%
% env : input signal envelope 
% multiplier : effort multiplication factor (typically and default 3)
% noiseThresh : for the onset time detection
%
% attEndIdx : attack offset index
% attStartIdx : attack onset index
%
% This function is borrowed and adapted/truncated from the Timbre Toolbox for comparison purposes only
% The original licence states that:
% 1 - the code is provided as is without any guarantee of suitability to any need;
% 2 - the use is strictly limited to non-profit, research activities and excludes any commercial use, including the computation of data to be integrated into a commercial application or service;
% 3 - no sub-licensing to any third party is allowed;
% 4 - any communication of work for which the code was used shall explicitely mention its use, the joint IRCAM and McGill University copyright, and, if a written publication, the reference to the related article: Peeters, G., Giordano, B.L., Susini, P., Misdariis, N. & McAdams, S. (in press). The Timbre Toolbox: Extracting audio descriptors from musical signals. Journal of the Acoustical Society of America.

%
% Copyright by IRCAM and McGill University
%
    if nargin<3
        noiseThresh=0;
        if nargin<2
            multiplier=3; % === facteur multiplicatif de l'effort
        end
    end
    
    envMax = max(env);
    normEnergyEnv = env / (envMax - eps); % normalize by maximum value
                
    % ============================================
    % === calcul de l'index du début d'atteinte de chaque niveau
    superlevelSetsDomainStep = 0.1;
    superlevelSetsDomain = superlevelSetsDomainStep:superlevelSetsDomainStep:1;
    superlevelSetsStartIdcs = zeros(1, length(superlevelSetsDomain));
    for i=1:length(superlevelSetsDomain)
        superlevelSetIdcs = find(normEnergyEnv >= superlevelSetsDomain(i));
        superlevelSetsStartIdcs(i) = superlevelSetIdcs(1);
    end
                
    % ==== détection du start (attStart) et du stop (attEnd) de l'attaque ========================
    superThreshSetIdcs 	= find(normEnergyEnv > noiseThresh);
    % === PARAMETRES
    midSuperlevelSetsDomainStartIdx	= round(0.3/superlevelSetsDomainStep); % === BORNES pour calcul mean
    midSuperlevelSetsDomainEndIdx	= round(0.6/superlevelSetsDomainStep);
    
    %multiplier = 3; % === facteur multiplicatif de l'effort %%% it is an input variable in this adaptation
    
    lowSuperlevelSetsDomainStartIdx	= round(0.1/superlevelSetsDomainStep); % === BORNES pour correction satt (start attack)
    lowSuperlevelSetsDomainEndIdx	= round(0.3/superlevelSetsDomainStep);
    
    highSuperlevelSetsDomainStartIdx= round(0.5/superlevelSetsDomainStep); % === BORNES pour correction eatt (end attack)
    highSuperlevelSetsDomainEndIdx	= round(0.9/superlevelSetsDomainStep);
    
    superlevelSetsLengths = diff(superlevelSetsStartIdcs); % === dpercent_posn_v = effort
    midSuperlevelSetsLengthsMean = mean(superlevelSetsLengths(midSuperlevelSetsDomainStartIdx:midSuperlevelSetsDomainEndIdx)); % === M = effort moyen
    
    % === 1) START ATTACK
    % === on DEMARRE juste APRES que l'effort à fournir (écart temporal entre percent) soit trop important
    tmpIdcs = find(superlevelSetsLengths(lowSuperlevelSetsDomainStartIdx:lowSuperlevelSetsDomainEndIdx) > multiplier*midSuperlevelSetsLengthsMean);
    if ~isempty(tmpIdcs)
        superlevelSetsDomainAttStartIdx = tmpIdcs(end)+lowSuperlevelSetsDomainStartIdx;
    else
        superlevelSetsDomainAttStartIdx = lowSuperlevelSetsDomainStartIdx;
    end
    attStartIdx = superlevelSetsStartIdcs(superlevelSetsDomainAttStartIdx);
    
    % === raffinement: on cherche le minimum local
    delta = round(0.25*(superlevelSetsLengths(superlevelSetsDomainAttStartIdx)));
    [~, normEnergyEnvAttStartLocalMinRelIdx]= min(normEnergyEnv(max([attStartIdx-delta 1]):min([attStartIdx+delta length(env)])));
    attStartIdx = normEnergyEnvAttStartLocalMinRelIdx + max([attStartIdx-delta 1]) - 1;
    
    % === 2) END ATTACK
    % === on ARRETE juste AVANT que l'effort à fournir (écart temporal entre niveaux) soit trop important
    tmpIdcs = find(superlevelSetsLengths(highSuperlevelSetsDomainStartIdx:highSuperlevelSetsDomainEndIdx) > multiplier*midSuperlevelSetsLengthsMean);
    if ~isempty(tmpIdcs)
        superlevelSetsDomainAttEndIdx = tmpIdcs(1)+highSuperlevelSetsDomainStartIdx-1;
    else
        superlevelSetsDomainAttEndIdx = highSuperlevelSetsDomainEndIdx+1;
    end
    attEndIdx = superlevelSetsStartIdcs(superlevelSetsDomainAttEndIdx);
    % === raffinement: on cherche le maximum local
    delta	= round(0.25*(superlevelSetsLengths(superlevelSetsDomainAttEndIdx-1)));
    [~, normEnergyEnvAttEndLocalMaxRelIdx] = max(normEnergyEnv(max([attEndIdx-delta 1]):min([attEndIdx+delta length(env)])));
    attEndIdx = normEnergyEnvAttEndLocalMaxRelIdx + max([attEndIdx-delta 1]) - 1;

end

