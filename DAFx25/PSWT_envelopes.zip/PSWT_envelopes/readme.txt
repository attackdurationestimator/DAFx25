The Matlab function set included in file PSWT_envelope_analysis_lite.m and 
the related testing script 'test_PSWT_envelope_analysis' were developed with 
Matlab version 23.2 (R2023 uodate 7). 
Although they may work with earlier releases of Matlab, this has not been tested.

The scripts require the following Matlab Toolboxes to be installed:
Signal Processing Toolbox
Audio Toolbox

This software, including the function called "PSWT_envelope_analysis_lite.m" 
and functions therein is exclusively provided as a demonstrator of the methods 
and algorithms for the analysis of envelopes of instrument sounds described 
in the paper "A Wavelet-Based Method for the Estimation of Clarity of Attack 
Parameters in Non-Percussive Instruments" by G. Evangelista and A. Acquilino, 
submitted for publication to the DAFx25 Conference, Ancona, Italy, Sept. 2-5, 2025

Any other use in non-profit or commercial applications without explicit consent 
by the authors is strictly forbidden.
Limited use in academic non-profit research is allowed provided that the source 
is duly mentioned, which includes citating the above mentioned publication 
and previous publications by each one of the authors.

Copyright (c) 1994-2025 by G. Evangelista and A. Acquilino with exeption of the function weakest_effort contained in the file PSWT_envelope_analysis_lite.m,
which bears joint Copyright by IRCAM and McGill University